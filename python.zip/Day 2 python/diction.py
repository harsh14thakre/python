d1={'Name':'Harsh', 1 : "Bhopal"}
print(d1[1])
d2={'Name':'Harsh'}
print(id(d1),id(d2))

# Store different memory address
# mutable in nature