x=10.5
y=10.5
print(id(x),id(y))
# same memory address 
