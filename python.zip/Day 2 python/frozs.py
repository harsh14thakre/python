# FROZENSET:-

f1=frozenset([10,20,30])
f2=frozenset([10,20,30])

print(id(f1),id(f2))

# Different memory address
# Immutable in nature, due to hashing technique