x=10
y=10
print(id(x),id(y))