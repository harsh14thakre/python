l1=[10,20,30]
l2=[10,20,30]
print(id(l1),id(l2))

# different memory address
# Mutable in nature