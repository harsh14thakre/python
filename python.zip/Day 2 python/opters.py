# Arithematic operator returns value


x=12345
y=x//10  #floor division 
z=x%10
print(y)
print(z)


# -----------------------------------------------------------------------------------------------


x=2
y=5
z=x**y
print(z)





