# SET:-

s1={10,20,30}
s2={10,20,30}
print(id(s1),id(s2))

# Different memory address
# Mutable in nature