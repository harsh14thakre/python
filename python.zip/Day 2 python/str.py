x='harsh'
y='harsh'
print(id(x),id(y))

# same memory address
# immutable in nature

