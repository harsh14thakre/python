#And &
#OR |
#Bitwise-not ~
#Bitwise X-OR ^
#left shift <<
#right shift >>



x=0b10
y=0B10
print(x,y)

x=0o10
y=0O10
print(x,y)

x=0o10
y=0O10
print(x,y)


x=10
y=15
print(x & y)