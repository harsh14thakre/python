
x=10
x+=1
print(x)

x-=1
print(x)

x*=1
print(x)

x%=1
print(x)

x/=1
print(x)

x//=1
print(x)

