# is 
#is not

x=10
y='10'
print(x==y)#false  #compares on the basis of value
print(x is y) #false  #compares on the basis of address
print(x is not y) #true


