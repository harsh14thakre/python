//-----------------------------------------OR operator----------------------------------
x=10
y=20
z=30
print(x>y or y>z)

print(x>y or y<z)
print(xy or y>z)
print(x>y or y>z)


// -------------------------------not operator--------------------------------------------


print(not(x<y and y>z))
// output true



// ------------------------------membership operator-----------------------------------------


// return boolean value 