# str="Python"
# print(str.index('t'))
# # ans=2;

# str="Python"
# print(str.index('th'))
# # ans=2;

l1=[10,20,30,'raj','jay',40]
print(l1.index(10))
print(l1[2])


